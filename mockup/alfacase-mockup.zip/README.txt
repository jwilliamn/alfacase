AlfaCase interactive mockup

1. Extract this ZIP file.
2. Open index.html in a normal browser tab (Chrome, Edge, Firefox or Safari).
   Do not open it in a chat visualization or source-code/file preview.

The HTML includes all styles, scripts and synthetic data. No server, install,
Internet connection, API key or model is required. JavaScript must be enabled.

Company switching, the scenario calculator and the agent-logic view work in the
browser. Sources and AI traces are clearly labeled simulations. Nothing is sent
to a bank or external service. State is cleared on reload.
